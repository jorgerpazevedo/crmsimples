/*
# [Fix] Update User Creation Trigger
[This migration updates the handle_new_user function to make it more secure and robust, resolving a potential cause for registration failures.]

## Query Description: [This operation modifies the function that automatically creates a user profile upon registration. It sets a fixed 'search_path' to prevent security vulnerabilities and ensure the function correctly locates the 'profiles' table. This change is safe and should fix the registration issue without affecting existing data.]

## Metadata:
- Schema-Category: ["Safe", "Structural"]
- Impact-Level: ["Low"]
- Requires-Backup: false
- Reversible: true

## Structure Details:
- Modifies function: public.handle_new_user()

## Security Implications:
- RLS Status: [Enabled]
- Policy Changes: [No]
- Auth Requirements: [None]
- Fixes "Function Search Path Mutable" security advisory.

## Performance Impact:
- Indexes: [None]
- Triggers: [No change to trigger, only function logic]
- Estimated Impact: [Negligible]
*/

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  user_role TEXT;
BEGIN
  -- Determine role based on email
  IF NEW.email = 'admin@crm.app' THEN
    user_role := 'admin';
  ELSE
    user_role := 'user';
  END IF;

  -- Insert a new profile, using the name from the metadata provided at sign up.
  INSERT INTO public.profiles (id, name, email, role)
  VALUES (NEW.id, NEW.raw_user_meta_data->>'name', NEW.email, user_role);
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;
