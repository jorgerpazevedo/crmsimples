/*
# [Fix] Robust User Profile Creation
[This migration updates the user creation trigger to be more robust, fixing the registration failure. It uses an `ON CONFLICT` clause to prevent errors if a profile already exists, guaranteeing that the user registration process can always complete successfully.]

## Query Description: [This operation replaces the `handle_new_user` function with a more resilient version. It will not affect any existing data. It ensures that all new user registrations will succeed by safely handling the creation of their corresponding profile entry.]

## Metadata:
- Schema-Category: ["Safe", "Structural"]
- Impact-Level: ["Low"]
- Requires-Backup: false
- Reversible: true

## Structure Details:
- Function: `public.handle_new_user()`
- Trigger: `on_auth_user_created` on `auth.users`

## Security Implications:
- RLS Status: [Enabled]
- Policy Changes: [No]
- Auth Requirements: [None]

## Performance Impact:
- Indexes: [None]
- Triggers: [Modified]
- Estimated Impact: [Negligible. Improves reliability of user creation.]
*/

-- Create a more robust function to handle new user creation
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
declare
  user_role text;
begin
  -- Determine the user's role based on their email address
  if new.email = 'admin@crm.app' then
    user_role := 'admin';
  else
    user_role := 'user';
  end if;

  -- Insert a new profile for the user.
  -- If a profile with the same ID already exists, do nothing.
  -- This prevents the trigger from failing and rolling back the user creation.
  insert into public.profiles (id, name, email, role)
  values (new.id, new.raw_user_meta_data->>'name', new.email, user_role)
  on conflict (id) do nothing;

  return new;
end;
$$;

-- Recreate the trigger to ensure it uses the updated function
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
