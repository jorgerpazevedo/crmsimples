/*
# Correcção da Base de Dados CRM
Migração para corrigir problemas de estrutura e adicionar colunas em falta

## Query Description: 
Esta migração corrige problemas de estrutura da base de dados, garantindo que todas as tabelas e colunas necessárias existem. 
Cria tabelas em falta e adiciona colunas que possam não existir. É uma operação segura que não afecta dados existentes.

## Metadata:
- Schema-Category: "Structural"
- Impact-Level: "Low"
- Requires-Backup: false
- Reversible: true

## Structure Details:
- Corrige tabela agents (se não existir)
- Corrige tabela traffic_sources (se não existir)
- Adiciona agent_id à tabela leads se não existir
- Corrige todas as foreign keys e índices
- Adiciona dados padrão se necessário

## Security Implications:
- RLS Status: Enabled em todas as tabelas
- Policy Changes: Yes
- Auth Requirements: Ligação à tabela auth.users

## Performance Impact:
- Indexes: Adicionados para performance
- Triggers: Actualizados
- Estimated Impact: Minimal impact, melhora performance
*/

-- Criar extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. TABELA AGENTS (criar se não existir)
CREATE TABLE IF NOT EXISTS public.agents (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. TABELA TRAFFIC_SOURCES (criar se não existir)
CREATE TABLE IF NOT EXISTS public.traffic_sources (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. VERIFICAR E ADICIONAR COLUNA agent_id À TABELA LEADS (se não existir)
DO $$
BEGIN
    -- Verificar se a coluna agent_id existe
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'leads' 
        AND table_schema = 'public' 
        AND column_name = 'agent_id'
    ) THEN
        ALTER TABLE public.leads ADD COLUMN agent_id UUID REFERENCES public.agents(id) ON DELETE SET NULL;
    END IF;
    
    -- Verificar se a coluna traffic_source_id existe
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'leads' 
        AND table_schema = 'public' 
        AND column_name = 'traffic_source_id'
    ) THEN
        ALTER TABLE public.leads ADD COLUMN traffic_source_id UUID REFERENCES public.traffic_sources(id) ON DELETE SET NULL;
    END IF;
END $$;

-- 4. TABELA LEAD_STATUS_TRACKING (criar se não existir)
CREATE TABLE IF NOT EXISTS public.lead_status_tracking (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    lead_id UUID NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
    stage_1 BOOLEAN DEFAULT false,
    stage_2 BOOLEAN DEFAULT false,
    stage_3 BOOLEAN DEFAULT false,
    stage_4 BOOLEAN DEFAULT false,
    stage_5 BOOLEAN DEFAULT false,
    stage_6 BOOLEAN DEFAULT false,
    stage_7 BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(lead_id)
);

-- 5. CRIAR TRIGGER DE ACTUALIZAÇÃO PARA TIMESTAMPS
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Aplicar triggers de updated_at se não existirem
DO $$
BEGIN
    -- Trigger para agents
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_agents_updated_at') THEN
        CREATE TRIGGER update_agents_updated_at 
            BEFORE UPDATE ON public.agents 
            FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    END IF;
    
    -- Trigger para leads
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_leads_updated_at') THEN
        CREATE TRIGGER update_leads_updated_at 
            BEFORE UPDATE ON public.leads 
            FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    END IF;
    
    -- Trigger para profiles
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_profiles_updated_at') THEN
        CREATE TRIGGER update_profiles_updated_at 
            BEFORE UPDATE ON public.profiles 
            FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    END IF;
    
    -- Trigger para lead_status_tracking
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_lead_status_tracking_updated_at') THEN
        CREATE TRIGGER update_lead_status_tracking_updated_at 
            BEFORE UPDATE ON public.lead_status_tracking 
            FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    END IF;
END $$;

-- 6. ACTIVAR RLS EM TODAS AS TABELAS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.agents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.leads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.traffic_sources ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lead_status_tracking ENABLE ROW LEVEL SECURITY;

-- 7. REMOVER POLÍTICAS EXISTENTES E RECRIAR
DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can view agents" ON public.agents;
DROP POLICY IF EXISTS "Users can manage agents" ON public.agents;
DROP POLICY IF EXISTS "Users can view leads" ON public.leads;
DROP POLICY IF EXISTS "Users can manage leads" ON public.leads;
DROP POLICY IF EXISTS "Users can view traffic sources" ON public.traffic_sources;
DROP POLICY IF EXISTS "Users can view lead tracking" ON public.lead_status_tracking;
DROP POLICY IF EXISTS "Users can manage lead tracking" ON public.lead_status_tracking;

-- 8. CRIAR POLÍTICAS RLS
-- Profiles
CREATE POLICY "Users can view own profile" ON public.profiles
    FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON public.profiles
    FOR UPDATE USING (auth.uid() = id);

-- Agents
CREATE POLICY "Users can view agents" ON public.agents
    FOR SELECT USING (auth.uid() IS NOT NULL);

CREATE POLICY "Users can manage agents" ON public.agents
    FOR ALL USING (auth.uid() IS NOT NULL);

-- Leads
CREATE POLICY "Users can view leads" ON public.leads
    FOR SELECT USING (auth.uid() IS NOT NULL);

CREATE POLICY "Users can manage leads" ON public.leads
    FOR ALL USING (auth.uid() IS NOT NULL);

-- Traffic Sources
CREATE POLICY "Users can view traffic sources" ON public.traffic_sources
    FOR SELECT USING (auth.uid() IS NOT NULL);

-- Lead Status Tracking
CREATE POLICY "Users can view lead tracking" ON public.lead_status_tracking
    FOR SELECT USING (auth.uid() IS NOT NULL);

CREATE POLICY "Users can manage lead tracking" ON public.lead_status_tracking
    FOR ALL USING (auth.uid() IS NOT NULL);

-- 9. INSERIR DADOS PADRÃO (apenas se não existirem)
INSERT INTO public.traffic_sources (name, description) 
SELECT * FROM (VALUES 
    ('CIP', 'Contacto direto CIP'),
    ('Referral', 'Referência de cliente'),
    ('Facebook Ads', 'Anúncios Facebook'),
    ('Google Ads', 'Anúncios Google'),
    ('Instagram', 'Rede social Instagram'),
    ('Website', 'Website directo'),
    ('LinkedIn', 'Rede social LinkedIn'),
    ('Cold Call', 'Chamada fria'),
    ('Email Marketing', 'Campanha de email'),
    ('Evento', 'Evento presencial')
) AS new_data(name, description)
WHERE NOT EXISTS (
    SELECT 1 FROM public.traffic_sources WHERE name = new_data.name
);

-- Inserir agente padrão Jorge Azevedo se não existir
INSERT INTO public.agents (name, email, phone)
SELECT 'Jorge Azevedo', 'jorge.azevedo@empresa.pt', '+351 912 345 678'
WHERE NOT EXISTS (
    SELECT 1 FROM public.agents WHERE name = 'Jorge Azevedo'
);

-- 10. CRIAR ÍNDICES PARA PERFORMANCE
CREATE INDEX IF NOT EXISTS idx_leads_agent_id ON public.leads(agent_id);
CREATE INDEX IF NOT EXISTS idx_leads_traffic_source_id ON public.leads(traffic_source_id);
CREATE INDEX IF NOT EXISTS idx_leads_status ON public.leads(status);
CREATE INDEX IF NOT EXISTS idx_leads_created_at ON public.leads(created_at);
CREATE INDEX IF NOT EXISTS idx_lead_status_tracking_lead_id ON public.lead_status_tracking(lead_id);
CREATE INDEX IF NOT EXISTS idx_profiles_email ON public.profiles(email);
CREATE INDEX IF NOT EXISTS idx_agents_user_id ON public.agents(user_id);

-- 11. TRIGGER PARA CRIAÇÃO AUTOMÁTICA DE PERFIL
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (id, name, email, role)
    VALUES (NEW.id, NEW.raw_user_meta_data->>'name', NEW.email, 'user');
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Remover trigger existente se houver
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- Criar novo trigger
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW
    WHEN (NEW.email_confirmed_at IS NOT NULL)
    EXECUTE FUNCTION public.handle_new_user();
