/*
# CRM Lead Management System - Schema Seguro
Sistema completo de CRM para gestão de leads baseado na folha de cálculo fornecida

## Query Description: 
Esta migração cria de forma segura o esquema necessário para o CRM de leads.
Verifica a existência de tabelas antes de as criar, evitando conflitos.
Inclui sistema de tracking com 7 estágios, gestão de agentes e fontes de tráfego.
Operação segura que não afecta dados existentes.

## Metadata:
- Schema-Category: "Safe"
- Impact-Level: "Low"
- Requires-Backup: false
- Reversible: true

## Structure Details:
- profiles: Perfis de utilizadores (verifica se existe)
- agents: Agentes comerciais
- traffic_sources: Fontes de tráfego (CIP, Facebook Ads, etc.)
- leads: Leads principais com todas as informações
- lead_status_tracking: Sistema de tracking com 7 estágios

## Security Implications:
- RLS Status: Enabled em todas as tabelas públicas
- Policy Changes: Yes
- Auth Requirements: Autenticação obrigatória para todas as operações

## Performance Impact:
- Indexes: Added em campos de pesquisa e foreign keys
- Triggers: Added para auto-criação de perfis
- Estimated Impact: Mínimo impacto, estrutura optimizada
*/

-- Extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Verificar e criar tabela profiles apenas se não existir
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'profiles') THEN
        CREATE TABLE public.profiles (
            id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
            name TEXT,
            email TEXT,
            role TEXT DEFAULT 'user',
            created_at TIMESTAMPTZ DEFAULT NOW(),
            updated_at TIMESTAMPTZ DEFAULT NOW()
        );
    END IF;
END $$;

-- 2. Criar tabela de agentes
CREATE TABLE IF NOT EXISTS public.agents (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Criar tabela de fontes de tráfego
CREATE TABLE IF NOT EXISTS public.traffic_sources (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Criar tabela principal de leads
CREATE TABLE IF NOT EXISTS public.leads (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    agent_id UUID REFERENCES public.agents(id) ON DELETE SET NULL,
    name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    gcc_value DECIMAL(10,2),
    last_contact DATE,
    refi_date DATE,
    traffic_source_id UUID REFERENCES public.traffic_sources(id) ON DELETE SET NULL,
    status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'converted', 'lost')),
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Criar tabela de tracking de status (7 estágios como na folha de cálculo)
CREATE TABLE IF NOT EXISTS public.lead_status_tracking (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    lead_id UUID REFERENCES public.leads(id) ON DELETE CASCADE NOT NULL,
    stage_1 BOOLEAN DEFAULT false,  -- Toque 1
    stage_2 BOOLEAN DEFAULT false,  -- Toque 2
    stage_3 BOOLEAN DEFAULT false,  -- Toque 3
    stage_4 BOOLEAN DEFAULT false,  -- Toque 4
    stage_5 BOOLEAN DEFAULT false,  -- Toque 5
    stage_6 BOOLEAN DEFAULT false,  -- Toque 6
    stage_7 BOOLEAN DEFAULT false,  -- Toque 7
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(lead_id)
);

-- 6. Criar índices para performance
CREATE INDEX IF NOT EXISTS idx_leads_agent_id ON public.leads(agent_id);
CREATE INDEX IF NOT EXISTS idx_leads_traffic_source ON public.leads(traffic_source_id);
CREATE INDEX IF NOT EXISTS idx_leads_status ON public.leads(status);
CREATE INDEX IF NOT EXISTS idx_leads_created_at ON public.leads(created_at);
CREATE INDEX IF NOT EXISTS idx_lead_tracking_lead_id ON public.lead_status_tracking(lead_id);

-- 7. Activar RLS (Row Level Security)
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.agents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.traffic_sources ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.leads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lead_status_tracking ENABLE ROW LEVEL SECURITY;

-- 8. Criar políticas de segurança

-- Políticas para profiles
DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
CREATE POLICY "Users can view own profile" ON public.profiles
    FOR SELECT USING (auth.uid() = id);

DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
CREATE POLICY "Users can update own profile" ON public.profiles
    FOR UPDATE USING (auth.uid() = id);

-- Políticas para agents
DROP POLICY IF EXISTS "Authenticated users can view agents" ON public.agents;
CREATE POLICY "Authenticated users can view agents" ON public.agents
    FOR SELECT USING (auth.role() = 'authenticated');

DROP POLICY IF EXISTS "Authenticated users can manage agents" ON public.agents;
CREATE POLICY "Authenticated users can manage agents" ON public.agents
    FOR ALL USING (auth.role() = 'authenticated');

-- Políticas para traffic_sources
DROP POLICY IF EXISTS "Authenticated users can view traffic sources" ON public.traffic_sources;
CREATE POLICY "Authenticated users can view traffic sources" ON public.traffic_sources
    FOR SELECT USING (auth.role() = 'authenticated');

DROP POLICY IF EXISTS "Authenticated users can manage traffic sources" ON public.traffic_sources;
CREATE POLICY "Authenticated users can manage traffic sources" ON public.traffic_sources
    FOR ALL USING (auth.role() = 'authenticated');

-- Políticas para leads
DROP POLICY IF EXISTS "Authenticated users can view leads" ON public.leads;
CREATE POLICY "Authenticated users can view leads" ON public.leads
    FOR SELECT USING (auth.role() = 'authenticated');

DROP POLICY IF EXISTS "Authenticated users can manage leads" ON public.leads;
CREATE POLICY "Authenticated users can manage leads" ON public.leads
    FOR ALL USING (auth.role() = 'authenticated');

-- Políticas para lead_status_tracking
DROP POLICY IF EXISTS "Authenticated users can view lead tracking" ON public.lead_status_tracking;
CREATE POLICY "Authenticated users can view lead tracking" ON public.lead_status_tracking
    FOR SELECT USING (auth.role() = 'authenticated');

DROP POLICY IF EXISTS "Authenticated users can manage lead tracking" ON public.lead_status_tracking;
CREATE POLICY "Authenticated users can manage lead tracking" ON public.lead_status_tracking
    FOR ALL USING (auth.role() = 'authenticated');

-- 9. Criar trigger para auto-criação de perfis
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (id, name, email)
    VALUES (NEW.id, NEW.raw_user_meta_data->>'name', NEW.email);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Remover trigger existente se existir
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- Criar novo trigger
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- 10. Inserir dados iniciais de fontes de tráfego (baseado na folha de cálculo)
INSERT INTO public.traffic_sources (name, description) VALUES
    ('CIP', 'Centro de Informação Promocional'),
    ('Referral', 'Indicação/Referência'),
    ('Facebook Ads', 'Publicidade no Facebook'),
    ('Google Ads', 'Publicidade no Google'),
    ('Social Media', 'Redes Sociais Orgânicas'),
    ('Website', 'Website Directo'),
    ('Email Marketing', 'Campanhas de Email'),
    ('Telefone', 'Contacto Telefónico Directo')
ON CONFLICT DO NOTHING;

-- 11. Criar agente padrão baseado na folha de cálculo
INSERT INTO public.agents (name, email, is_active) VALUES
    ('Jorge Azevedo', 'jorge.azevedo@empresa.com', true)
ON CONFLICT DO NOTHING;

-- 12. Criar função para actualizar timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Aplicar triggers de timestamp
DROP TRIGGER IF EXISTS update_agents_updated_at ON public.agents;
CREATE TRIGGER update_agents_updated_at
    BEFORE UPDATE ON public.agents
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

DROP TRIGGER IF EXISTS update_leads_updated_at ON public.leads;
CREATE TRIGGER update_leads_updated_at
    BEFORE UPDATE ON public.leads
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

DROP TRIGGER IF EXISTS update_profiles_updated_at ON public.profiles;
CREATE TRIGGER update_profiles_updated_at
    BEFORE UPDATE ON public.profiles
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

DROP TRIGGER IF EXISTS update_lead_tracking_updated_at ON public.lead_status_tracking;
CREATE TRIGGER update_lead_tracking_updated_at
    BEFORE UPDATE ON public.lead_status_tracking
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
