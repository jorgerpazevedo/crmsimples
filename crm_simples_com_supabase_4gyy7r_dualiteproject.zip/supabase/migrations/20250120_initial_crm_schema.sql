/*
# Configuração Inicial do CRM
Criação das tabelas principais para gestão de leads e agentes do CRM

## Query Description: 
Esta migração cria a estrutura base do CRM incluindo tabelas para utilizadores, agentes, leads e fontes de tráfego. 
É uma operação segura que apenas adiciona novas tabelas sem afetar dados existentes.

## Metadata:
- Schema-Category: "Safe"
- Impact-Level: "Low"
- Requires-Backup: false
- Reversible: true

## Structure Details:
- profiles: Tabela de perfis de utilizador ligada ao auth.users
- agents: Tabela de agentes/vendedores
- traffic_sources: Fontes de tráfego (CIP, Referral, Facebook Ads, etc.)
- leads: Tabela principal de leads com todas as informações
- lead_status_tracking: Acompanhamento do estado dos leads (colunas 1-7)

## Security Implications:
- RLS Status: Enabled em todas as tabelas
- Policy Changes: Yes
- Auth Requirements: Utilizadores autenticados apenas

## Performance Impact:
- Indexes: Adicionados em campos chave
- Triggers: Trigger para criação automática de perfil
- Estimated Impact: Mínimo, apenas criação de estrutura
*/

-- Extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Tabela de perfis (ligada ao auth.users)
CREATE TABLE profiles (
    id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
    name TEXT,
    email TEXT,
    role TEXT DEFAULT 'user' CHECK (role IN ('admin', 'agent', 'user')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de agentes
CREATE TABLE agents (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de fontes de tráfego
CREATE TABLE traffic_sources (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Inserir fontes de tráfego padrão
INSERT INTO traffic_sources (name, description) VALUES
('CIP', 'Centro de Informação Profissional'),
('Referral', 'Indicação'),
('Facebook Ads', 'Anúncios Facebook'),
('Social Media', 'Redes Sociais'),
('Google Ads', 'Anúncios Google'),
('Website', 'Website Direto');

-- Tabela principal de leads
CREATE TABLE leads (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    agent_id UUID REFERENCES agents(id) ON DELETE SET NULL,
    name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    gcc_value DECIMAL(10,2), -- Valor em euros
    last_contact DATE,
    refi_date DATE,
    traffic_source_id UUID REFERENCES traffic_sources(id) ON DELETE SET NULL,
    status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'converted', 'lost')),
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela para acompanhamento do estado dos leads (colunas 1-7)
CREATE TABLE lead_status_tracking (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    lead_id UUID REFERENCES leads(id) ON DELETE CASCADE,
    stage_1 BOOLEAN DEFAULT false,
    stage_2 BOOLEAN DEFAULT false,
    stage_3 BOOLEAN DEFAULT false,
    stage_4 BOOLEAN DEFAULT false,
    stage_5 BOOLEAN DEFAULT false,
    stage_6 BOOLEAN DEFAULT false,
    stage_7 BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(lead_id)
);

-- Índices para performance
CREATE INDEX idx_leads_agent_id ON leads(agent_id);
CREATE INDEX idx_leads_status ON leads(status);
CREATE INDEX idx_leads_created_at ON leads(created_at);
CREATE INDEX idx_lead_status_tracking_lead_id ON lead_status_tracking(lead_id);

-- Trigger para criar perfil automaticamente
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO profiles (id, name, email)
    VALUES (
        NEW.id,
        COALESCE(NEW.raw_user_meta_data->>'name', NEW.email),
        NEW.email
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Policies RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE agents ENABLE ROW LEVEL SECURITY;
ALTER TABLE traffic_sources ENABLE ROW LEVEL SECURITY;
ALTER TABLE leads ENABLE ROW LEVEL SECURITY;
ALTER TABLE lead_status_tracking ENABLE ROW LEVEL SECURITY;

-- Policies para profiles
CREATE POLICY "Utilizadores podem ver o próprio perfil" ON profiles
    FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Utilizadores podem atualizar o próprio perfil" ON profiles
    FOR UPDATE USING (auth.uid() = id);

-- Policies para agents
CREATE POLICY "Utilizadores autenticados podem ver agentes" ON agents
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Apenas admins podem inserir agentes" ON agents
    FOR INSERT WITH CHECK (
        EXISTS (
            SELECT 1 FROM profiles 
            WHERE id = auth.uid() AND role = 'admin'
        )
    );

-- Policies para traffic_sources
CREATE POLICY "Utilizadores autenticados podem ver fontes" ON traffic_sources
    FOR SELECT USING (auth.role() = 'authenticated');

-- Policies para leads
CREATE POLICY "Utilizadores podem ver todos os leads" ON leads
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Utilizadores podem inserir leads" ON leads
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Utilizadores podem atualizar leads" ON leads
    FOR UPDATE USING (auth.role() = 'authenticated');

-- Policies para lead_status_tracking
CREATE POLICY "Utilizadores podem ver tracking" ON lead_status_tracking
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Utilizadores podem inserir tracking" ON lead_status_tracking
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Utilizadores podem atualizar tracking" ON lead_status_tracking
    FOR UPDATE USING (auth.role() = 'authenticated');
