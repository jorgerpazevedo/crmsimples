/*
  # [Bootstrap Admin Role]
  [This operation updates the user creation logic to automatically assign the 'admin' role to the first user who signs up. Subsequent users will be assigned the 'user' role.]

  ## Query Description: [This script modifies the `handle_new_user` function. When a new user signs up, it checks if an admin already exists. If not, the new user becomes the admin. This is a one-time setup for the first account. It is safe to run and does not affect existing data, only the creation of new users.]
  
  ## Metadata:
  - Schema-Category: ["Structural"]
  - Impact-Level: ["Low"]
  - Requires-Backup: [false]
  - Reversible: [true]
  
  ## Structure Details:
  - Modifies function: `public.handle_new_user()`
  - Affects table: `public.profiles` (on insert)
  
  ## Security Implications:
  - RLS Status: [Enabled]
  - Policy Changes: [No]
  - Auth Requirements: [Triggers on new user signup]
  
  ## Performance Impact:
  - Indexes: [No change]
  - Triggers: [Modifies existing trigger logic]
  - Estimated Impact: [Negligible impact on signup performance.]
*/

-- Drop the existing trigger and function to ensure a clean update
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user();

-- Create the new function to handle user creation with admin bootstrapping
CREATE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  admin_exists BOOLEAN;
BEGIN
  -- Check if an admin user already exists
  SELECT EXISTS (SELECT 1 FROM public.profiles WHERE role = 'admin') INTO admin_exists;

  -- If no admin exists, make this new user the admin.
  -- Otherwise, assign the default 'user' role.
  IF NOT admin_exists THEN
    INSERT INTO public.profiles (id, name, email, role)
    VALUES (new.id, new.raw_user_meta_data->>'name', new.email, 'admin');
  ELSE
    INSERT INTO public.profiles (id, name, email, role)
    VALUES (new.id, new.raw_user_meta_data->>'name', new.email, 'user');
  END IF;
  
  RETURN new;
END;
$$;

-- Recreate the trigger to call the new function
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
