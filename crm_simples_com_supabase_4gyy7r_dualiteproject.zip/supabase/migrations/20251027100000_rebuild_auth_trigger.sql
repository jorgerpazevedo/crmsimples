/*
          # [REBUILD] Reconstrução da Lógica de Criação de Utilizador

          [Este script substitui completamente a função e o trigger responsáveis pela criação de perfis de utilizador após o registo. A versão anterior era instável e causava falhas no registo. Esta nova versão é robusta, segura e segue as melhores práticas recomendadas pela Supabase.]

          ## Query Description: [Esta operação é segura. Ela remove a lógica antiga e defeituosa e implementa uma nova versão corrigida. Não há risco de perda de dados de utilizadores existentes, pois apenas afeta a criação de *novos* utilizadores. Garante que todos os futuros registos (incluindo o do administrador) funcionem corretamente.]
          
          ## Metadata:
          - Schema-Category: "Structural"
          - Impact-Level: "Low"
          - Requires-Backup: false
          - Reversible: false
          
          ## Structure Details:
          - Dropped: `function handle_new_user`, `trigger on_auth_user_created`
          - Created: `function handle_new_user` (com SECURITY DEFINER), `trigger on_auth_user_created`
          
          ## Security Implications:
          - RLS Status: A nova função usa `SECURITY DEFINER` para contornar RLS durante a inserção do perfil, o que é uma prática padrão e segura para este cenário, garantindo que a criação do perfil não falhe devido a políticas de RLS.
          - Policy Changes: No
          - Auth Requirements: N/A
          
          ## Performance Impact:
          - Indexes: None
          - Triggers: O trigger é recriado de forma mais eficiente.
          - Estimated Impact: Positivo. Resolve o bloqueio na criação de utilizadores.
          */

-- 1. Remover a função antiga e o trigger para garantir um ambiente limpo.
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user();

-- 2. Criar a nova função, mais robusta e segura.
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER -- Executa com os privilégios do criador, contornando RLS de forma segura.
SET search_path = public
AS $$
DECLARE
  user_role TEXT;
BEGIN
  -- Define o papel do utilizador. Se o email for 'admin@crm.app', é 'admin'. Senão, é 'user'.
  IF NEW.email = 'admin@crm.app' THEN
    user_role := 'admin';
  ELSE
    user_role := 'user';
  END IF;

  -- Insere o novo perfil na tabela 'profiles'.
  -- Usa os dados do novo registo em 'auth.users'.
  INSERT INTO public.profiles (id, name, email, role)
  VALUES (
    NEW.id,
    NEW.raw_user_meta_data->>'name',
    NEW.email,
    user_role
  );
  
  RETURN NEW;
END;
$$;

-- 3. Criar o novo trigger que chama a função correta após um novo utilizador ser criado.
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- 4. Garantir que o dono da função é o correto para o SECURITY DEFINER funcionar.
ALTER FUNCTION public.handle_new_user() OWNER TO postgres;
