/*
          # [Operação] Atualizar Lógica de Criação de Utilizador para Admin Específico
          [Descrição: Modifica a função que cria um perfil de utilizador para atribuir o papel de 'admin' a um email específico no momento do registo.]

          ## Query Description: [Esta operação altera a função `handle_new_user` para que, ao criar um novo utilizador, verifique se o email corresponde a 'admin@crm.app'. Se corresponder, atribui o papel 'admin'; caso contrário, atribui 'user'. Isto garante um método determinístico para criar uma conta de administrador sem afetar os utilizadores existentes. A operação é segura e não altera dados existentes.]
          
          ## Metadata:
          - Schema-Category: "Structural"
          - Impact-Level: "Low"
          - Requires-Backup: false
          - Reversible: true
          
          ## Structure Details:
          - Function: `public.handle_new_user()`
          - Trigger: `on_auth_user_created` on `auth.users`
          
          ## Security Implications:
          - RLS Status: Enabled
          - Policy Changes: No
          - Auth Requirements: Apenas o sistema (trigger) invoca esta função.
          
          ## Performance Impact:
          - Indexes: None
          - Triggers: Modificado
          - Estimated Impact: Nenhum impacto de performance notável.
          */

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  admin_email TEXT := 'admin@crm.app'; -- O email reservado para o administrador
BEGIN
  INSERT INTO public.profiles (id, name, email, role)
  VALUES (
    new.id,
    new.raw_user_meta_data->>'name',
    new.email,
    -- Atribui o papel 'admin' se o email for o do administrador, senão 'user'
    CASE
      WHEN new.email = admin_email THEN 'admin'
      ELSE 'user'
    END
  );
  RETURN new;
END;
$$;

-- Garante que o trigger está a usar a função mais recente.
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

COMMENT ON FUNCTION public.handle_new_user() IS 'Cria um perfil para um novo utilizador e atribui o papel de admin se o email for o predefinido.';
