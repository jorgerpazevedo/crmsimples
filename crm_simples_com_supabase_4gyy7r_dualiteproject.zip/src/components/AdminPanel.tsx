import React, { useState, useEffect } from 'react';
import { Users, Globe, Settings, BarChart3, Plus, Edit2, Trash2, Check, X } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface AdminPanelProps {
  addToast: (message: string, type: 'success' | 'error' | 'info') => void;
}

interface Agent {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  is_active: boolean;
  created_at: string;
  lead_count?: number;
}

interface TrafficSource {
  id: string;
  name: string;
  description: string | null;
  is_active: boolean;
  created_at: string;
  lead_count?: number;
}

interface AdminStats {
  totalUsers: number;
  totalAgents: number;
  totalTrafficSources: number;
  totalLeads: number;
  activeLeads: number;
  convertedLeads: number;
  totalValue: number;
}

export function AdminPanel({ addToast }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<'agents' | 'traffic-sources' | 'stats'>('stats');
  const [agents, setAgents] = useState<Agent[]>([]);
  const [trafficSources, setTrafficSources] = useState<TrafficSource[]>([]);
  const [stats, setStats] = useState<AdminStats>({
    totalUsers: 0,
    totalAgents: 0,
    totalTrafficSources: 0,
    totalLeads: 0,
    activeLeads: 0,
    convertedLeads: 0,
    totalValue: 0
  });
  const [loading, setLoading] = useState(true);
  const [editingAgent, setEditingAgent] = useState<Agent | null>(null);
  const [editingTrafficSource, setEditingTrafficSource] = useState<TrafficSource | null>(null);
  const [showAddAgentForm, setShowAddAgentForm] = useState(false);
  const [showAddTrafficSourceForm, setShowAddTrafficSourceForm] = useState(false);

  // Form states
  const [agentForm, setAgentForm] = useState({
    name: '',
    email: '',
    phone: '',
    is_active: true
  });

  const [trafficSourceForm, setTrafficSourceForm] = useState({
    name: '',
    description: '',
    is_active: true
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      await Promise.all([
        fetchAgents(),
        fetchTrafficSources(),
        fetchStats()
      ]);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      addToast('Erro ao carregar dados do painel', 'error');
    } finally {
      setLoading(false);
    }
  };

  const fetchAgents = async () => {
    const { data, error } = await supabase
      .from('agents')
      .select(`
        *,
        lead_count:leads(count)
      `)
      .order('created_at', { ascending: false });

    if (error) throw error;
    setAgents(data?.map(agent => ({
      ...agent,
      lead_count: agent.lead_count?.[0]?.count || 0
    })) || []);
  };

  const fetchTrafficSources = async () => {
    const { data, error } = await supabase
      .from('traffic_sources')
      .select(`
        *,
        lead_count:leads(count)
      `)
      .order('created_at', { ascending: false });

    if (error) throw error;
    setTrafficSources(data?.map(source => ({
      ...source,
      lead_count: source.lead_count?.[0]?.count || 0
    })) || []);
  };

  const fetchStats = async () => {
    // Total users
    const { count: totalUsers } = await supabase
      .from('profiles')
      .select('*', { count: 'exact', head: true });

    // Total leads
    const { data: leadsData } = await supabase
      .from('leads')
      .select('status, gcc_value');

    const totalLeads = leadsData?.length || 0;
    const activeLeads = leadsData?.filter(l => l.status === 'active').length || 0;
    const convertedLeads = leadsData?.filter(l => l.status === 'converted').length || 0;
    const totalValue = leadsData?.reduce((sum, lead) => sum + (lead.gcc_value || 0), 0) || 0;

    // Total agents
    const { count: totalAgents } = await supabase
      .from('agents')
      .select('*', { count: 'exact', head: true });

    // Total traffic sources
    const { count: totalTrafficSources } = await supabase
      .from('traffic_sources')
      .select('*', { count: 'exact', head: true });

    setStats({
      totalUsers: totalUsers || 0,
      totalAgents: totalAgents || 0,
      totalTrafficSources: totalTrafficSources || 0,
      totalLeads,
      activeLeads,
      convertedLeads,
      totalValue
    });
  };

  const handleCreateAgent = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const { error } = await supabase
        .from('agents')
        .insert([agentForm]);

      if (error) throw error;
      
      addToast('Agente criado com sucesso!', 'success');
      setAgentForm({ name: '', email: '', phone: '', is_active: true });
      setShowAddAgentForm(false);
      fetchAgents();
    } catch (error) {
      console.error('Erro ao criar agente:', error);
      addToast('Erro ao criar agente', 'error');
    }
  };

  const handleUpdateAgent = async (agent: Agent) => {
    try {
      const { error } = await supabase
        .from('agents')
        .update({
          name: agent.name,
          email: agent.email,
          phone: agent.phone,
          is_active: agent.is_active,
          updated_at: new Date().toISOString()
        })
        .eq('id', agent.id);

      if (error) throw error;
      
      addToast('Agente actualizado com sucesso!', 'success');
      setEditingAgent(null);
      fetchAgents();
    } catch (error) {
      console.error('Erro ao actualizar agente:', error);
      addToast('Erro ao actualizar agente', 'error');
    }
  };

  const handleDeleteAgent = async (id: string) => {
    if (window.confirm('Tem a certeza que quer eliminar este agente?')) {
      try {
        const { error } = await supabase
          .from('agents')
          .delete()
          .eq('id', id);

        if (error) throw error;
        
        addToast('Agente eliminado com sucesso!', 'success');
        fetchAgents();
      } catch (error) {
        console.error('Erro ao eliminar agente:', error);
        addToast('Erro ao eliminar agente', 'error');
      }
    }
  };

  const handleCreateTrafficSource = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const { error } = await supabase
        .from('traffic_sources')
        .insert([trafficSourceForm]);

      if (error) throw error;
      
      addToast('Fonte de tráfego criada com sucesso!', 'success');
      setTrafficSourceForm({ name: '', description: '', is_active: true });
      setShowAddTrafficSourceForm(false);
      fetchTrafficSources();
    } catch (error) {
      console.error('Erro ao criar fonte de tráfego:', error);
      addToast('Erro ao criar fonte de tráfego', 'error');
    }
  };

  const handleUpdateTrafficSource = async (source: TrafficSource) => {
    try {
      const { error } = await supabase
        .from('traffic_sources')
        .update({
          name: source.name,
          description: source.description,
          is_active: source.is_active
        })
        .eq('id', source.id);

      if (error) throw error;
      
      addToast('Fonte de tráfego actualizada com sucesso!', 'success');
      setEditingTrafficSource(null);
      fetchTrafficSources();
    } catch (error) {
      console.error('Erro ao actualizar fonte de tráfego:', error);
      addToast('Erro ao actualizar fonte de tráfego', 'error');
    }
  };

  const handleDeleteTrafficSource = async (id: string) => {
    if (window.confirm('Tem a certeza que quer eliminar esta fonte de tráfego?')) {
      try {
        const { error } = await supabase
          .from('traffic_sources')
          .delete()
          .eq('id', id);

        if (error) throw error;
        
        addToast('Fonte de tráfego eliminada com sucesso!', 'success');
        fetchTrafficSources();
      } catch (error) {
        console.error('Erro ao eliminar fonte de tráfego:', error);
        addToast('Erro ao eliminar fonte de tráfego', 'error');
      }
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-PT', {
      style: 'currency',
      currency: 'EUR'
    }).format(value);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-PT');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">A carregar painel de administração...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="border-b border-gray-200">
        <div className="flex space-x-8">
          <button
            onClick={() => setActiveTab('stats')}
            className={`py-2 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'stats'
                ? 'border-indigo-500 text-indigo-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            <BarChart3 className="w-4 h-4 inline mr-2" />
            Estatísticas
          </button>
          <button
            onClick={() => setActiveTab('agents')}
            className={`py-2 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'agents'
                ? 'border-indigo-500 text-indigo-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            <Users className="w-4 h-4 inline mr-2" />
            Agentes ({agents.length})
          </button>
          <button
            onClick={() => setActiveTab('traffic-sources')}
            className={`py-2 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'traffic-sources'
                ? 'border-indigo-500 text-indigo-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            <Globe className="w-4 h-4 inline mr-2" />
            Fontes de Tráfego ({trafficSources.length})
          </button>
        </div>
      </div>

      {/* Content */}
      {activeTab === 'stats' && (
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-gray-900">Estatísticas do Sistema</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white p-6 rounded-lg shadow">
              <div className="flex items-center">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <Users className="w-6 h-6 text-blue-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Utilizadores</p>
                  <p className="text-2xl font-semibold text-gray-900">{stats.totalUsers}</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow">
              <div className="flex items-center">
                <div className="p-2 bg-green-100 rounded-lg">
                  <BarChart3 className="w-6 h-6 text-green-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Leads</p>
                  <p className="text-2xl font-semibold text-gray-900">{stats.totalLeads}</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow">
              <div className="flex items-center">
                <div className="p-2 bg-indigo-100 rounded-lg">
                  <Users className="w-6 h-6 text-indigo-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Agentes Activos</p>
                  <p className="text-2xl font-semibold text-gray-900">{stats.totalAgents}</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow">
              <div className="flex items-center">
                <div className="p-2 bg-yellow-100 rounded-lg">
                  <Globe className="w-6 h-6 text-yellow-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Fontes de Tráfego</p>
                  <p className="text-2xl font-semibold text-gray-900">{stats.totalTrafficSources}</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow">
              <div className="flex items-center">
                <div className="p-2 bg-green-100 rounded-lg">
                  <BarChart3 className="w-6 h-6 text-green-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Leads Activos</p>
                  <p className="text-2xl font-semibold text-gray-900">{stats.activeLeads}</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow">
              <div className="flex items-center">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <BarChart3 className="w-6 h-6 text-blue-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Leads Convertidos</p>
                  <p className="text-2xl font-semibold text-gray-900">{stats.convertedLeads}</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow md:col-span-2">
              <div className="flex items-center">
                <div className="p-2 bg-purple-100 rounded-lg">
                  <BarChart3 className="w-6 h-6 text-purple-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Valor Total Portfolio</p>
                  <p className="text-2xl font-semibold text-gray-900">{formatCurrency(stats.totalValue)}</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Taxa de Conversão</h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm">
                  <span>Leads Convertidos</span>
                  <span>{stats.totalLeads > 0 ? ((stats.convertedLeads / stats.totalLeads) * 100).toFixed(1) : 0}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-indigo-600 h-2 rounded-full" 
                    style={{ width: `${stats.totalLeads > 0 ? (stats.convertedLeads / stats.totalLeads) * 100 : 0}%` }}
                  ></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'agents' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold text-gray-900">Gestão de Agentes</h2>
            <button
              onClick={() => setShowAddAgentForm(true)}
              className="flex items-center space-x-2 bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700"
            >
              <Plus className="w-4 h-4" />
              <span>Adicionar Agente</span>
            </button>
          </div>

          {showAddAgentForm && (
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Novo Agente</h3>
              <form onSubmit={handleCreateAgent} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Nome *</label>
                  <input
                    type="text"
                    required
                    value={agentForm.name}
                    onChange={(e) => setAgentForm(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                  <input
                    type="email"
                    value={agentForm.email}
                    onChange={(e) => setAgentForm(prev => ({ ...prev, email: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Telefone</label>
                  <input
                    type="tel"
                    value={agentForm.phone}
                    onChange={(e) => setAgentForm(prev => ({ ...prev, phone: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="agent-active"
                    checked={agentForm.is_active}
                    onChange={(e) => setAgentForm(prev => ({ ...prev, is_active: e.target.checked }))}
                    className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                  />
                  <label htmlFor="agent-active" className="text-sm text-gray-700">Agente activo</label>
                </div>
                <div className="md:col-span-2 flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => setShowAddAgentForm(false)}
                    className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
                  >
                    Criar Agente
                  </button>
                </div>
              </form>
            </div>
          )}

          <div className="bg-white rounded-lg shadow overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nome</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Telefone</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Leads</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Estado</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Criado</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Acções</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {agents.map((agent) => (
                  <tr key={agent.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {editingAgent?.id === agent.id ? (
                        <input
                          type="text"
                          value={editingAgent.name}
                          onChange={(e) => setEditingAgent(prev => prev ? { ...prev, name: e.target.value } : null)}
                          className="w-full px-2 py-1 border border-gray-300 rounded text-sm"
                        />
                      ) : (
                        <div className="text-sm font-medium text-gray-900">{agent.name}</div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {editingAgent?.id === agent.id ? (
                        <input
                          type="email"
                          value={editingAgent.email || ''}
                          onChange={(e) => setEditingAgent(prev => prev ? { ...prev, email: e.target.value } : null)}
                          className="w-full px-2 py-1 border border-gray-300 rounded text-sm"
                        />
                      ) : (
                        <div className="text-sm text-gray-900">{agent.email || '-'}</div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {editingAgent?.id === agent.id ? (
                        <input
                          type="tel"
                          value={editingAgent.phone || ''}
                          onChange={(e) => setEditingAgent(prev => prev ? { ...prev, phone: e.target.value } : null)}
                          className="w-full px-2 py-1 border border-gray-300 rounded text-sm"
                        />
                      ) : (
                        <div className="text-sm text-gray-900">{agent.phone || '-'}</div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
                        {agent.lead_count || 0} leads
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {editingAgent?.id === agent.id ? (
                        <input
                          type="checkbox"
                          checked={editingAgent.is_active}
                          onChange={(e) => setEditingAgent(prev => prev ? { ...prev, is_active: e.target.checked } : null)}
                          className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                        />
                      ) : (
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                          agent.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {agent.is_active ? 'Activo' : 'Inactivo'}
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {formatDate(agent.created_at)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      {editingAgent?.id === agent.id ? (
                        <div className="flex space-x-2">
                          <button
                            onClick={() => handleUpdateAgent(editingAgent)}
                            className="text-green-600 hover:text-green-900"
                          >
                            <Check className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setEditingAgent(null)}
                            className="text-gray-600 hover:text-gray-900"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ) : (
                        <div className="flex space-x-2">
                          <button
                            onClick={() => setEditingAgent(agent)}
                            className="text-indigo-600 hover:text-indigo-900"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteAgent(agent.id)}
                            className="text-red-600 hover:text-red-900"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'traffic-sources' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold text-gray-900">Gestão de Fontes de Tráfego</h2>
            <button
              onClick={() => setShowAddTrafficSourceForm(true)}
              className="flex items-center space-x-2 bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700"
            >
              <Plus className="w-4 h-4" />
              <span>Adicionar Fonte</span>
            </button>
          </div>

          {showAddTrafficSourceForm && (
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Nova Fonte de Tráfego</h3>
              <form onSubmit={handleCreateTrafficSource} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Nome *</label>
                  <input
                    type="text"
                    required
                    value={trafficSourceForm.name}
                    onChange={(e) => setTrafficSourceForm(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Descrição</label>
                  <input
                    type="text"
                    value={trafficSourceForm.description}
                    onChange={(e) => setTrafficSourceForm(prev => ({ ...prev, description: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="source-active"
                    checked={trafficSourceForm.is_active}
                    onChange={(e) => setTrafficSourceForm(prev => ({ ...prev, is_active: e.target.checked }))}
                    className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                  />
                  <label htmlFor="source-active" className="text-sm text-gray-700">Fonte activa</label>
                </div>
                <div className="md:col-span-2 flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => setShowAddTrafficSourceForm(false)}
                    className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
                  >
                    Criar Fonte
                  </button>
                </div>
              </form>
            </div>
          )}

          <div className="bg-white rounded-lg shadow overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nome</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Descrição</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Leads</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Estado</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Criado</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Acções</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {trafficSources.map((source) => (
                  <tr key={source.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {editingTrafficSource?.id === source.id ? (
                        <input
                          type="text"
                          value={editingTrafficSource.name}
                          onChange={(e) => setEditingTrafficSource(prev => prev ? { ...prev, name: e.target.value } : null)}
                          className="w-full px-2 py-1 border border-gray-300 rounded text-sm"
                        />
                      ) : (
                        <div className="text-sm font-medium text-gray-900">{source.name}</div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {editingTrafficSource?.id === source.id ? (
                        <input
                          type="text"
                          value={editingTrafficSource.description || ''}
                          onChange={(e) => setEditingTrafficSource(prev => prev ? { ...prev, description: e.target.value } : null)}
                          className="w-full px-2 py-1 border border-gray-300 rounded text-sm"
                        />
                      ) : (
                        <div className="text-sm text-gray-900">{source.description || '-'}</div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
                        {source.lead_count || 0} leads
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {editingTrafficSource?.id === source.id ? (
                        <input
                          type="checkbox"
                          checked={editingTrafficSource.is_active}
                          onChange={(e) => setEditingTrafficSource(prev => prev ? { ...prev, is_active: e.target.checked } : null)}
                          className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                        />
                      ) : (
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                          source.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {source.is_active ? 'Activa' : 'Inactiva'}
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {formatDate(source.created_at)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      {editingTrafficSource?.id === source.id ? (
                        <div className="flex space-x-2">
                          <button
                            onClick={() => handleUpdateTrafficSource(editingTrafficSource)}
                            className="text-green-600 hover:text-green-900"
                          >
                            <Check className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setEditingTrafficSource(null)}
                            className="text-gray-600 hover:text-gray-900"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ) : (
                        <div className="flex space-x-2">
                          <button
                            onClick={() => setEditingTrafficSource(source)}
                            className="text-indigo-600 hover:text-indigo-900"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteTrafficSource(source.id)}
                            className="text-red-600 hover:text-red-900"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
