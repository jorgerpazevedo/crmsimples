import React, { useState, useEffect } from 'react';
import { X, Loader2 } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface Lead {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  gcc_value: number | null;
  last_contact: string | null;
  refi_date: string | null;
  traffic_source_id: string | null;
  agent_id: string | null;
  status: string;
  notes: string | null;
}

interface EditLeadModalProps {
  lead: Lead;
  onClose: () => void;
  onSuccess: () => void;
  addToast: (message: string, type: 'success' | 'error' | 'info') => void;
}

interface TrafficSource {
  id: string;
  name: string;
}

interface Agent {
  id: string;
  name: string;
}

export function EditLeadModal({ lead, onClose, onSuccess, addToast }: EditLeadModalProps) {
  const [formData, setFormData] = useState({
    name: lead.name,
    email: lead.email || '',
    phone: lead.phone || '',
    gcc_value: lead.gcc_value?.toString() || '',
    last_contact: lead.last_contact ? lead.last_contact.split('T')[0] : '',
    refi_date: lead.refi_date ? lead.refi_date.split('T')[0] : '',
    traffic_source_id: lead.traffic_source_id || '',
    agent_id: lead.agent_id || '',
    status: lead.status,
    notes: lead.notes || ''
  });
  
  const [trafficSources, setTrafficSources] = useState<TrafficSource[]>([]);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchTrafficSources();
    fetchAgents();
  }, []);

  const fetchTrafficSources = async () => {
    try {
      const { data, error } = await supabase
        .from('traffic_sources')
        .select('id, name')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      setTrafficSources(data || []);
    } catch (error) {
      console.error('Erro ao carregar fontes de tráfego:', error);
      addToast('Erro ao carregar fontes de tráfego', 'error');
    }
  };

  const fetchAgents = async () => {
    try {
      const { data, error } = await supabase
        .from('agents')
        .select('id, name')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      setAgents(data || []);
    } catch (error) {
      console.error('Erro ao carregar agentes:', error);
      addToast('Erro ao carregar agentes', 'error');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const updateData = {
        ...formData,
        gcc_value: formData.gcc_value ? parseFloat(formData.gcc_value) : null,
        last_contact: formData.last_contact || null,
        refi_date: formData.refi_date || null,
        traffic_source_id: formData.traffic_source_id || null,
        agent_id: formData.agent_id || null,
        updated_at: new Date().toISOString()
      };

      const { error } = await supabase
        .from('leads')
        .update(updateData)
        .eq('id', lead.id);

      if (error) throw error;

      onSuccess();
    } catch (error) {
      console.error('Erro ao actualizar lead:', error);
      addToast('Erro ao actualizar lead. Tente novamente.', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-screen overflow-y-auto">
        <div className="flex justify-between items-center p-6 border-b">
          <h2 className="text-xl font-semibold text-gray-900">Editar Lead</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Nome *
              </label>
              <input
                type="text"
                name="name"
                required
                value={formData.name}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Telefone
              </label>
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Valor GCC (€)
              </label>
              <input
                type="number"
                name="gcc_value"
                step="0.01"
                value={formData.gcc_value}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Último Contacto
              </label>
              <input
                type="date"
                name="last_contact"
                value={formData.last_contact}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Data REFI
              </label>
              <input
                type="date"
                name="refi_date"
                value={formData.refi_date}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Fonte de Tráfego
              </label>
              <select
                name="traffic_source_id"
                value={formData.traffic_source_id}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="">Seleccionar fonte...</option>
                {trafficSources.map((source) => (
                  <option key={source.id} value={source.id}>
                    {source.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Agente
              </label>
              <select
                name="agent_id"
                value={formData.agent_id}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="">Seleccionar agente...</option>
                {agents.map((agent) => (
                  <option key={agent.id} value={agent.id}>
                    {agent.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Estado
              </label>
              <select
                name="status"
                value={formData.status}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="active">Activo</option>
                <option value="inactive">Inactivo</option>
                <option value="converted">Convertido</option>
                <option value="lost">Perdido</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Notas
            </label>
            <textarea
              name="notes"
              rows={3}
              value={formData.notes}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="Observações sobre o lead..."
            />
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 disabled:opacity-50 flex items-center space-x-2"
            >
              {loading && <Loader2 className="w-4 h-4 animate-spin" />}
              <span>Actualizar Lead</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
