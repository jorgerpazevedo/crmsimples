import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';

interface SignUpResponse {
  data: {
    user: User | null;
    session: Session | null;
  } | null;
  error: any | null;
}

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  isAdmin: boolean;
  signIn: (email: string, password: string) => Promise<{ error: any }>;
  signUp: (email: string, password: string, name: string) => Promise<SignUpResponse>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  // Efeito 1: Ouve as mudanças de autenticação do Supabase
  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      setUser(session?.user ?? null);
    });

    // Pega na sessão inicial para cobrir o primeiro carregamento da página
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  // Efeito 2: Busca o perfil do utilizador quando o objeto 'user' está disponível ou muda
  useEffect(() => {
    if (user) {
      // Temos um utilizador, agora vamos buscar o seu perfil. O 'loading' continua true.
      supabase.from('profiles').select('role').eq('id', user.id).single()
        .then(({ data, error }) => {
          if (!error && data) {
            setIsAdmin(data.role === 'admin');
          } else {
            setIsAdmin(false);
            if (error) console.error('Erro ao buscar perfil:', error.message);
          }
          // Agora que temos o perfil (ou falhou), podemos parar o loading.
          setLoading(false);
        });
    } else {
      // Sem utilizador, não é admin, e podemos parar o loading.
      setIsAdmin(false);
      setLoading(false);
    }
  }, [user]); // A dependência em 'user' é a chave

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    return { error };
  };

  const signUp = async (email: string, password: string, name: string): Promise<SignUpResponse> => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          name,
        },
        emailRedirectTo: `${window.location.origin}/`,
      },
    });
    return { data, error };
  };

  const signOut = async () => {
    await supabase.auth.signOut();
  };

  const value = {
    user,
    session,
    loading,
    isAdmin,
    signIn,
    signUp,
    signOut,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth deve ser usado dentro de um AuthProvider');
  }
  return context;
}
