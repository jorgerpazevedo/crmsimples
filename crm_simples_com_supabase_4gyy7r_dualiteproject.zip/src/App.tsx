import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { AuthForm } from './components/AuthForm';
import { CRMTable } from './components/CRMTable';
import { ToastContainer } from './components/ToastContainer';
import { useToast } from './hooks/useToast';

function AppContent() {
  const { user, loading } = useAuth();
  const { toasts, addToast, removeToast } = useToast();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">A carregar CRM...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      {user ? <CRMTable addToast={addToast} /> : <AuthForm addToast={addToast} />}
      <ToastContainer toasts={toasts} onRemove={removeToast} />
    </>
  );
}

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/" element={<AppContent />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
