import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Variáveis de ambiente do Supabase em falta');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          name: string | null;
          email: string | null;
          role: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          name?: string | null;
          email?: string | null;
          role?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          name?: string | null;
          email?: string | null;
          role?: string;
          created_at?: string;
          updated_at?: string;
        };
      };
      agents: {
        Row: {
          id: string;
          user_id: string | null;
          name: string;
          email: string | null;
          phone: string | null;
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id?: string | null;
          name: string;
          email?: string | null;
          phone?: string | null;
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string | null;
          name?: string;
          email?: string | null;
          phone?: string | null;
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      leads: {
        Row: {
          id: string;
          agent_id: string | null;
          name: string;
          email: string | null;
          phone: string | null;
          gcc_value: number | null;
          last_contact: string | null;
          refi_date: string | null;
          traffic_source_id: string | null;
          status: string;
          notes: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          agent_id?: string | null;
          name: string;
          email?: string | null;
          phone?: string | null;
          gcc_value?: number | null;
          last_contact?: string | null;
          refi_date?: string | null;
          traffic_source_id?: string | null;
          status?: string;
          notes?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          agent_id?: string | null;
          name?: string;
          email?: string | null;
          phone?: string | null;
          gcc_value?: number | null;
          last_contact?: string | null;
          refi_date?: string | null;
          traffic_source_id?: string | null;
          status?: string;
          notes?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      traffic_sources: {
        Row: {
          id: string;
          name: string;
          description: string | null;
          is_active: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          description?: string | null;
          is_active?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          description?: string | null;
          is_active?: boolean;
          created_at?: string;
        };
      };
      lead_status_tracking: {
        Row: {
          id: string;
          lead_id: string;
          stage_1: boolean;
          stage_2: boolean;
          stage_3: boolean;
          stage_4: boolean;
          stage_5: boolean;
          stage_6: boolean;
          stage_7: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          lead_id: string;
          stage_1?: boolean;
          stage_2?: boolean;
          stage_3?: boolean;
          stage_4?: boolean;
          stage_5?: boolean;
          stage_6?: boolean;
          stage_7?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          lead_id?: string;
          stage_1?: boolean;
          stage_2?: boolean;
          stage_3?: boolean;
          stage_4?: boolean;
          stage_5?: boolean;
          stage_6?: boolean;
          stage_7?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
    };
  };
};
